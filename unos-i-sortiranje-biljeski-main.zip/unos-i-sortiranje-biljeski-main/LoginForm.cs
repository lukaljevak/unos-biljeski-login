﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UnosBiljeski
{
    public partial class LoginForm : Form
    {

        
        private readonly List<Korisnik> korisnici = new List<Korisnik>
        {
            new Korisnik("admin", "admin123", "Administrator"),
            new Korisnik("user", "user123", "Korisnik")
        };

        public Korisnik PrijavljeniKorisnik { get; private set; }

        public LoginForm()
        {
            InitializeComponent();
        }

        private void BtnPrijava_Click(object sender, EventArgs e)
        {
            string korisnickoIme = txtKorisnickoIme.Text;
            string lozinka = txtLozinka.Text;


            PrijavljeniKorisnik = korisnici.FirstOrDefault(k => k.KorisnickoIme == korisnickoIme && k.Lozinka == lozinka);

            if (PrijavljeniKorisnik != null)
            {
                this.DialogResult = DialogResult.OK; 
                this.Close();
            }
            else
            {
                MessageBox.Show("Neispravno korisničko ime ili lozinka.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnPrijava_Click_1(object sender, EventArgs e)
        {

        }
    }
}
