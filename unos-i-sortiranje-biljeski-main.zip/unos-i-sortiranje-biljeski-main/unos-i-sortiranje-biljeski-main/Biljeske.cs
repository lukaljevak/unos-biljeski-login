﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace NoteSort
{
    public class Biljeske // Klasa mora biti public
    {
        public List<Biljeska> ListaBiljeski { get; set; } = new List<Biljeska>();

        public void SpremiUXml(string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Biljeske));
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    serializer.Serialize(writer, this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri spremanju bilješki u XML: " + ex.Message);
            }
        }

        public static Biljeske UcitajIzXml(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Biljeske));
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        return (Biljeske)serializer.Deserialize(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju bilješki iz XML: " + ex.Message);
            }
            return new Biljeske();
        }
    }
}