﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using UnosBiljeski;

namespace NoteSort
{
    public partial class Notes : Form
    {
        private Biljeske biljeske = new Biljeske();
        private readonly string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NoteSort", "notes.xml");
        private readonly Korisnik prijavljeniKorisnik;

        public Notes(Korisnik korisnik)
        {
            InitializeComponent();
            prijavljeniKorisnik = korisnik;
            LoadNotes();
            OmoguciFunkcionalnosti();
        }

        private void OmoguciFunkcionalnosti()
        {
            if (prijavljeniKorisnik.Uloga == "Korisnik")
            {
                
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void Notes_Load(object sender, EventArgs e)
        {
            
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            upisBiljeske upisForm = new upisBiljeske(this);
            upisForm.ShowDialog();
        }

        public void AddNote(string naslov, string opis)
        {
            biljeske.ListaBiljeski.Add(new Biljeska(naslov, opis));
            SaveNotes();
            dataGridView1.DataSource = null; 
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var odabranaBiljeska = (Biljeska)dataGridView1.CurrentRow.DataBoundItem;
                upisBiljeske upisForm = new upisBiljeske(this, odabranaBiljeska.Naslov, odabranaBiljeska.Opis, dataGridView1.CurrentRow.Index);
                upisForm.ShowDialog();
            }
        }

        public void UpdateNote(int index, string naslov, string opis)
        {
            biljeske.ListaBiljeski[index].Naslov = naslov;
            biljeske.ListaBiljeski[index].Opis = opis;
            SaveNotes();
            dataGridView1.DataSource = null; // Osvježi DataGridView
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var result = MessageBox.Show("Jeste li sigurni da želite obrisati ovu bilješku?", "Potvrdi brisanje", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    biljeske.ListaBiljeski.RemoveAt(dataGridView1.CurrentRow.Index);
                    SaveNotes();
                    dataGridView1.DataSource = null; // Osvježi DataGridView
                    dataGridView1.DataSource = biljeske.ListaBiljeski;
                }
            }
        }

        private void SaveNotes()
        {
            biljeske.SpremiUXml(filePath);
        }

        private void LoadNotes()
        {
            biljeske = Biljeske.UcitajIzXml(filePath);
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            SaveNotes();
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            string filter = txtSearch.Text.ToLower();
            var filtriraneBiljeske = biljeske.ListaBiljeski
                .Where(b => b.Naslov.ToLower().Contains(filter) || b.Opis.ToLower().Contains(filter))
                .ToList();
            dataGridView1.DataSource = filtriraneBiljeske;
        }
    }
}